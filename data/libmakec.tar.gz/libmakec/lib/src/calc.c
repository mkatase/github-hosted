#include <stdio.h>
#include "calc.h"

int calc(int x)
{
    return x*x;
}

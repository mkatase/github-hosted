#include <stdio.h>
#include "display.h"

void display()
{
    printf("Hello C World !!\n");
}

// hello.h
#ifndef _HELLO_H
#define _HELLO_H

char *hello(char *);

#endif

// display.h
#ifndef _DISPLAY_H
#define _DISPLAY_H

void display(void);

#endif

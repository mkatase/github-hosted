// calc.h
#ifndef _CALC_H
#define _CALC_H

int calc(int);

#endif

#include <stdio.h>

#include "calc.h"
#include "display.h"
#include "hello.h"

int main(void)
{
    display();
    printf("-----\n");
    printf("%d\n", calc(3));
    printf("-----\n");
    printf("%s\n", hello("Momo"));
}
